package com.journaldev.androidlivedata;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class Cart extends AppCompatActivity {

    private cartAdapter mFavAdapter;
    private CartViewModel mFavViewModel;
    private List<Products> mFav;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        fab = findViewById(R.id.fab);
        final RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mFavViewModel = ViewModelProviders.of(this).get(CartViewModel.class);
        final Observer<List<Products>> favsObserver = new Observer<List<Products>>() {
            @Override
            public void onChanged(@Nullable final List<Products> updatedList) {
                if (mFav == null) {
                    mFav = updatedList;
                    mFavAdapter = new cartAdapter(getApplicationContext(), mFav, new onclickListener() {
                        @Override
                        public void onItemClick(Products item, View v, int position) {

                        }
                    });
                    recyclerView.setAdapter(mFavAdapter);
                } else {
                    DiffUtil.DiffResult result = DiffUtil.calculateDiff(new DiffUtil.Callback() {

                        @Override
                        public int getOldListSize() {
                            return mFav.size();
                        }

                        @Override
                        public int getNewListSize() {
                            return updatedList.size();
                        }

                        @Override
                        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                            return mFav.get(oldItemPosition).mId ==
                                    updatedList.get(newItemPosition).mId;
                        }

                        @Override
                        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
                            Products oldFav = mFav.get(oldItemPosition);
                            Products newFav = updatedList.get(newItemPosition);
                            return oldFav.equals(newFav);
                        }
                    });
                    result.dispatchUpdatesTo(mFavAdapter);
                    mFav = updatedList;
                }
            }
        };
        mFavViewModel.getFavs().observe(this, favsObserver);
    }

    public class cartAdapter extends RecyclerView.Adapter<cartAdapter.cartViewHolder> {

        private Context context;
        private List<Products> mFavItems;
        onclickListener mlistener;

        public cartAdapter(Context context, List<Products> navDrawerItems, onclickListener listener) {
            this.context = context;
            this.mFavItems = navDrawerItems;
            this.mlistener = listener;
        }

        @Override
        public int getItemCount() {
            return mFavItems.size();
        }

        @Override
        public cartAdapter.cartViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_row, parent, false);
            return new cartAdapter.cartViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(cartAdapter.cartViewHolder holder, int position) {
            Products favourites = mFavItems.get(position);
            holder.mTxtTitle.setText(favourites.mName);
            holder.mTxtCount.setText(favourites.mQuantity);
            holder.image.setImageBitmap(BitmapFactory.decodeByteArray(favourites.mImage1, 0, favourites.mImage1.length));
        }


        class cartViewHolder extends RecyclerView.ViewHolder {

            TextView mTxtTitle;
            TextView mTxtCount;
            ImageView image;
            TextView quantity;
            ImageView plus;
            ImageView minus;
            ImageView delete;

            int pos = getAdapterPosition();
            Products favourites = mFavItems.get(pos);
            int quantity1 = favourites.mQuantity;

            cartViewHolder(View itemView) {
                super(itemView);

                mTxtTitle = itemView.findViewById(R.id.name);
                mTxtCount = itemView.findViewById(R.id.price);
                image = itemView.findViewById(R.id.icon);
                quantity = itemView.findViewById(R.id.quantity);
                plus = itemView.findViewById(R.id.cart_plus_img);
                minus = itemView.findViewById(R.id.cart_minus_img);
                delete = itemView.findViewById(R.id.imageView7);
                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mFavViewModel.removeFav(pos);
                    }
                });

                plus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        quantity1++;
                        new ProductsViewModel().updateFav(pos, quantity1);
                        quantity.setText(String.valueOf(quantity1));
                    }
                });
                minus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        quantity1--;
                        new ProductsViewModel().updateFav(pos, quantity1);
                        quantity.setText(String.valueOf(quantity1));
                    }
                });
            }
        }
    }
}