package com.journaldev.androidlivedata;

        import android.app.Application;
        import android.arch.lifecycle.AndroidViewModel;
        import android.arch.lifecycle.MutableLiveData;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import com.journaldev.androidlivedata.db.ProductssDBHelper;
        import java.util.ArrayList;
        import java.util.List;

public class CartViewModel extends AndroidViewModel {

    private ProductssDBHelper mFavHelper;
    private MutableLiveData<List<Products>> mFavs;

    CartViewModel(Application application) {
        super(application);
        mFavHelper = new ProductssDBHelper(application);
    }

    public MutableLiveData<List<Products>> getFavs() {
        if (mFavs == null) {
            mFavs = new MutableLiveData<>();
            loadFavs1();
        }

        return mFavs;
    }

    public void loadFavs1() {
        List<Products> newFavs1 = new ArrayList<>();
        SQLiteDatabase db = mFavHelper.getReadableDatabase();
        Cursor cursor = db.query("ProductDetails",
                new String[]{"Id","Name","Description","Category","Price","Cart","Image1","Image2","Quantity","Seller"},
                null, null, null, null, null);
        while (cursor.moveToNext()) {
            newFavs1.add(new Products(cursor.getLong(0), cursor.getString(1),cursor.getString(2),cursor.getString(3), cursor.getInt(5),cursor.getLong(4),cursor.getBlob(6),cursor.getBlob(7),cursor.getInt(8),cursor.getString(9)));
        }
        cursor.close();
        db.close();
        mFavs.setValue(newFavs1);
    }

    public void removeFav(long id) {
        List<Products> favs = mFavs.getValue();
        ArrayList<Products> clonedFavs = new ArrayList<>(favs.size());
        for (int i = 0; i < favs.size(); i++) {
            clonedFavs.add(new Products(favs.get(i)));
        }

        int index = -1;
        for (int i = 0; i < clonedFavs.size(); i++) {
            Products favourites = clonedFavs.get(i);
            if (favourites.mId == id) {
                index = i;
            }
        }
        if (index != -1) {
            clonedFavs.remove(index);
        }
        mFavs.setValue(clonedFavs);
    }
}

