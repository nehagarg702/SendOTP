package com.journaldev.androidlivedata;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class Add_Product extends AppCompatActivity {
    ImageView image1,image2;
    byte [] image11,image12;
    EditText name,Description, Price, Category,Seller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__product);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
            name=(EditText)findViewById(R.id.editText5);
        Description=(EditText)findViewById(R.id.editText6);
       Price=(EditText)findViewById(R.id.editText7);
        Category=(EditText)findViewById(R.id.editText8);
        Seller=(EditText)findViewById(R.id.editText);
        image1=(ImageView)findViewById(R.id.imageView3);
        image1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i,"Select Picture"),1);
            }
        });
        image2=(ImageView)findViewById(R.id.imageView4);
        image2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i,"Select Picture"),2);
            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(name.getText().toString().length()==0)
                {
                    Toast.makeText(getApplicationContext(),"Name is empty",Toast.LENGTH_LONG).show();
                }
                else if(Description.getText().toString().length()==0)
                {
                    Toast.makeText(getApplicationContext(),"Description is empty",Toast.LENGTH_LONG).show();
                }
                else if(Category.getText().toString().length()==0)
                {
                    Toast.makeText(getApplicationContext(),"Category is empty",Toast.LENGTH_LONG).show();
                }
                else if(Price.getText().toString().length()==0)
                {
                    Toast.makeText(getApplicationContext(),"Price is empty",Toast.LENGTH_LONG).show();
                }
                else if(Seller.getText().toString().length()==0)
                    Toast.makeText(getApplicationContext(),"Please enter seller details",Toast.LENGTH_LONG).show();
                else if(image11==null)
                    Toast.makeText(getApplicationContext(),"Image1 is empty",Toast.LENGTH_LONG).show();
                else if(image12==null)
                    Toast.makeText(getApplicationContext(),"Image2 is empty",Toast.LENGTH_LONG).show();
                else
                    new ProductsViewModel().addFav(name.getText().toString(),Description.getText().toString(),Category.getText().toString(),0,Integer.parseInt(Price.getText().toString()),image11,image12,0,Seller.getText().toString());
                Intent i=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
                finish();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
            try {
                final Uri imageUri = data.getData();
                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                selectedImage.compress(Bitmap.CompressFormat.PNG, 10, stream);
                if(requestCode==1) {
                    image1.setImageBitmap(selectedImage);
                    image11=stream.toByteArray();
                }
                if(requestCode==2) {
                    image12=stream.toByteArray();
                    image2.setImageBitmap(selectedImage);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(Add_Product.this, "Something went wrong", Toast.LENGTH_LONG).show();
            }
    }
}
