package com.journaldev.androidlivedata;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private FavAdapter mFavAdapter;
    private ProductsViewModel mFavViewModel;
    private List<Products> mFav;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fab = findViewById(R.id.fab);
        final RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        if (mFav == null) {
            mFav = mFavViewModel.loadFavs();
            mFavAdapter = new FavAdapter(getApplicationContext(), mFav, new onclickListener() {
                @Override
                public void onItemClick(Products item, View v, int position) {
                    Toast.makeText(getApplicationContext(), item.mDescription+" abcd "+item.mCategory, Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(getApplicationContext(),Display_Product.class);
                    i.putExtra("product_detail",position);
                    startActivity(i);
                }
            });
            recyclerView.setAdapter(mFavAdapter);
        }
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Add_Product.class);
                startActivity(i);
                finish();
            }
        });
    }

}
