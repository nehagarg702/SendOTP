public class Products {

    public long mId;
    public String mName;
	public String mDescription;
public String mCategory;
public long mPrice;
public byte[] mImage1;
public byte[] mImage2;
    public Integer mQuantity;

    public Products(long id, String name, String Description, String category, long price, Byte[] Image1, byte[] Image2, Integer qyantity) {
        mId = id;
        mName = name;
		mCategory=category;
mPrice=price
mImage1=Image1;
mImage2=Image2;
mQuantity=quantity;
        mDescription = Description;
    }

    public Products(products products) {
        mId = products.mId;
        mName = products.mName;
		mCategory=products.mCategory;
		mPrice=products.mPrice;
		mImage1=products.mImage1;
		mImage2=products.mImage2;
		mQuantity=products.mQuantity;
		mDescription=products.mDescription;
    }

}