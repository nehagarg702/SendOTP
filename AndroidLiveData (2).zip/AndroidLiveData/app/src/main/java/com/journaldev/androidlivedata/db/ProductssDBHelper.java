package com.journaldev.androidlivedata.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ProductssDBHelper extends SQLiteOpenHelper {

    public ProductssDBHelper(Context context) {
        super(context, DbSettings.DB_NAME, null, DbSettings.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE ProductDetails( Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL, Description Text not null, Category Text not null, Price INTEGER NOT NULL, Cart Integer not null, Image1 Blob, Image2 Blob, Quantity Integer, Seller Text);";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS ProductDetails");
        onCreate(db);
    }

}