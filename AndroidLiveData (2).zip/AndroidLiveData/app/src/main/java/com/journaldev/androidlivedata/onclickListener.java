package com.journaldev.androidlivedata;

import android.view.View;

/**
 * Created by ngarg3 on 1/10/2019.
 */

public interface onclickListener {
    public void onItemClick(Products item,View v, int position);
}
