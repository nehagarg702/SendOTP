import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class ProductsViewModel extends AndroidViewModel {

    private ProductsDBHelper mFavHelper;
    private MutableLiveData<List<Products>> mFavs;

    ProductsViewModel(Application application) {
        super(application);
        mFavHelper = new ProductsDBHelper(application);
    }

    public MutableLiveData<List<Products>> getFavs() {
        if (mFavs == null) {
            mFavs = new MutableLiveData<>();
            loadFavs();
        }

        return mFavs;
    }

    private void loadFavs() {
        List<Products> newFavs = new ArrayList<>();
        SQLiteDatabase db = mFavHelper.getReadableDatabase();
        Cursor cursor = db.query(DbSettings.DBEntry.TABLE,
                new String[]{"Id","Name","Description","Category","Price","cart","Image1","Image2","Quantity"},
                null, null, null, null, null);
        while (cursor.moveToNext()) {
            newFavs.add(new Products(cursor.getLong(0), cursor.getString(1),cursor.getString(2),cursor.getString(3), cursor.getInt(5),cursor.getLong(4),cursor.getBlob(6),cursor.getBlob(7),cursor.getInt(8)));
        }

        cursor.close();
        db.close();
        mFavs.setValue(newFavs);
    }


    public void addFav(String name, String Description, String category, Integer cart, long price, Byte[] Image1, Byte[] Image2, Integer qyantity) {

        SQLiteDatabase db = mFavHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Name", name);
        values.put("Description", Description);
        values.put("Category", category);
        values.put("Cart", cart);
        values.put("Price", price);
        values.put("Image1", Image1);
        values.put("Image2", Image2);
        values.put("Quantity", quantity);
        long id = db.insertWithOnConflict(DbSettings.DBEntry.TABLE,
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
        List<Products> Products = mFavs.getValue();
        ArrayList<Products> clonedFavs;
        if (Products == null) {
            clonedFavs = new ArrayList<>();
        } else {
            clonedFavs = new ArrayList<>(Products.size());
            for (int i = 0; i < Products.size(); i++) {
                clonedFavs.add(new Products(Products.get(i)));
            }
        }

        Products fav = new Products(id, name, Description,category,cart,price,Image1, Image2,quantity);
        clonedFavs.add(fav);
        mFavs.setValue(clonedFavs);
    }
}
