package com.journaldev.androidlivedata;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.journaldev.androidlivedata.Products;
import com.journaldev.androidlivedata.db.ProductssDBHelper;

import java.util.ArrayList;
import java.util.List;

public class ProductsViewModel {

    private ProductssDBHelper mFavHelper;
    private List<Products> mFavs;


    public List<Products> loadFavs() {
        List<Products> newFavs = new ArrayList<>();
        SQLiteDatabase db = mFavHelper.getReadableDatabase();
        Cursor cursor = db.query("ProductDetails",
                new String[]{"Id","Name","Description","Category","Price","Cart","Image1","Image2","Quantity","Seller"},
                null, null, null, null, null);
        while (cursor.moveToNext()) {
            newFavs.add(new Products(cursor.getLong(0), cursor.getString(1),cursor.getString(2),cursor.getString(3), cursor.getInt(5),cursor.getLong(4),cursor.getBlob(6),cursor.getBlob(7),cursor.getInt(8),cursor.getString(9)));
        }

        cursor.close();
        db.close();
        return  newFavs;
    }


    public void addFav(String name, String Description, String category, Integer cart, long price, byte[] Image1, byte[] Image2, Integer quantity, String Seller) {

        SQLiteDatabase db = mFavHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Name", name);
        values.put("Description", Description);
        values.put("Category", category);
        values.put("Cart", cart);
        values.put("Price", price);
        values.put("Image1", Image1);
        values.put("Image2", Image2);
        values.put("Quantity", quantity);
        values.put("Seller",Seller);
        long id = db.insertWithOnConflict("ProductDetails",
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }

    public void updateFav(long Id, int Cart) {

        SQLiteDatabase db = mFavHelper.getWritableDatabase();
        String strSQL = "UPDATE ProductDetails SET Cart = "+Cart+" WHERE Id = "+ Id;
        db.execSQL(strSQL);
        db.close();
    }

    public void updateQuantity(long Id, int Quantity) {

        SQLiteDatabase db = mFavHelper.getWritableDatabase();
        String strSQL = "UPDATE ProductDetails SET Quantity = "+Quantity+" WHERE Id = "+ Id;
        db.execSQL(strSQL);
        db.close();
    }
}
